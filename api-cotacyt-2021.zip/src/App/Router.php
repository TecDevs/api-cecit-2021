<?php

require __DIR__ . '/../Routes/AreaRoutes.php';
require __DIR__ . '/../Routes/AuthorRoutes.php';
require __DIR__ . '/../Routes/CampusRoutes.php';
require __DIR__ . '/../Routes/CategoryRoutes.php';
require __DIR__ . '/../Routes/ModalityRoutes.php';
require __DIR__ . '/../Routes/ProjectRoutes.php';
